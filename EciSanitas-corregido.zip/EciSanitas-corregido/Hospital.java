import java.util.ArrayList;
import java.time.LocalDate;

public class Hospital {
    private String name;
    private String address;
    private ArrayList<Office> offices;
    private ArrayList<Doctor> doctors;
    private Location location;
    private ArrayList<Treatment> treatments;
    
    /* Crea una cita en el hospital para un paciente que requiere una especialidad, una fecha y una franja especifica 
     * 
     * Entre todos sus doctores busca uno que tenga dispoinibilidad y ademas sea de la especialidad requerida
     * 
     * @param patient           El paciente al cual le queremos crear la cita
     * @param requestedSpeciality La especialidad medica solicitada para la cita
     * @param date              La fecha en la que se desea agendar la cita.
     * @param timeSlot          El numero que representa la franja horaria
     */
    public void createAppointment(Patient patient, String requestedSpeciality, LocalDate date, int timeSlot ){
        for (Doctor d : doctors){
            String ds = d.getSpeciality(); 
            boolean ia = d.isAvaible(date, timeSlot);
            if (requestedSpeciality.equals(ds) && ia){
                generateAppointment(patient,d, date, timeSlot);
            }
         }
    }
    
    /* Dado un doctor y paciente en especifico crea una cita 
     * 
     * @param patient           El paciente al cual le queremos crear la cita
     * @param doctor            El doctor que va a atender la cita
     * @param date              La fecha en la que se desea agendar la cita.
     * @param timeSlot          El numero que representa la franja horaria
     */
    private void generateAppointment(Patient patient, Doctor doctor, LocalDate date, int timeSlot){
        Office o = doctor.getOffice();
        if(o != null){
            Appointment a = new Appointment(doctor, o, date, timeSlot);
            patient.addAppointment(a);
        }
    }
}
