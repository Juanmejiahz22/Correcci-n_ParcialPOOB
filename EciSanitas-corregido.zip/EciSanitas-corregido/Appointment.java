import java.time.LocalDate;
import java.util.ArrayList;

public class Appointment {
    private String id;
    private LocalDate fecha;
    private int time;
    private String reason;
    private Doctor doctor;
    private Office office;
    private ArrayList<Treatment> patientTreatments;
    private ArrayList<PatientIllness> patientIllnesses;
    
    private static int numAppointment = 0;
    
    /* Constructor de la clase Appointment.
     * 
     * Crea una nueva cita para un paciente con un doctor especifico, en una oficina dada, una fecha y una hora
     * Para la id para que se aunica tenemos una variable estatica que representa el numero de citas hasta el momento
     * 
     * @param doctor    El doctor asignado a la cita.
     * @param office    La oficina o consultorio donde se realizará la cita.
     * @param date              La fecha en la que se desea agendar la cita.
     * @param timeSlot          El numero que representa la franja horaria
     */
    public Appointment(Doctor doctor, Office office, LocalDate date, int timeSlot){
        this.id = numAppointment + "";
        this.fecha = date;
        this.time = timeSlot;
        this.reason = "";
        this.doctor = doctor;
        this.office = office;
        this.patientTreatments = new ArrayList<>();
        this.patientIllnesses = new ArrayList<>();
        numAppointment++;
    }
}
