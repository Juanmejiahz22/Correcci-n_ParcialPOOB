import java.util.Collection;
import java.util.TreeMap;
import java.time.LocalDate;

public class ECISanitas {
    
    private TreeMap<String,Patient> patients;
    private TreeMap<String,Illness> ilnesses;
    private TreeMap<String,Hospital> hospitals;
    
    /* Programa una cita para un paciente especifico en un hospital especifico dada una especialidad especifica, un dia y hora
     * 
     * En caso de que el paciente o el hospital no exista no se programa 
     * 
     * @param patientId         El string que identifica al paciente
     * @param hospitalName      El strign que identifica al hospital
     * @param requestedSpeciality La especialidad medica solicitada para la cita
     * @param date              La fecha en la que se desea agendar la cita.
     * @param timeSlot          El numero que representa la franja horaria
     */
    public void scheduleAppointment(String patientId, String hospitalName, String requestedSpeciality, LocalDate date, int timeSlot){
        Patient p = getPatient(patientId);
        Hospital h = getHospital(hospitalName);
        if (p != null && h != null){
            h.createAppointment(p, requestedSpeciality, date, timeSlot);
        }
    }
    
    /**
     * Obtiene un objeto de tipo Patient a partir de su ID.
     *
     * @param patientId el identificador del paciente que se busca
     * @return el objeto Patient asociado al ID dado, o null si no se encuentra
     */
    private Patient getPatient(String patientId) {
        return patients.get(patientId); 
    }
    
    /**
     * Obtiene un objeto de tipo Hospital a partir de su nombre.
     *
     * @param hospitalName el nombre del hospital que se busca
     * @return el objeto Hospital asociado al nombre dado, o null si no se encuentra
     */
    private Hospital getHospital(String hospitalName) {
        return hospitals.get(hospitalName); 
    }
}
