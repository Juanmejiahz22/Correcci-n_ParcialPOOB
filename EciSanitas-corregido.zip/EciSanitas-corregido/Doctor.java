import java.time.LocalDate;

public class Doctor {
    private String id;
    private String name;
    private String specialty;
    private String phone;
    private Office office;
    
    /*
    * Obtiene la espcialidad del doctor
    */
    public String getSpeciality(){
        return specialty;
    }
    
    /* Verifica si el doctor tiene disponibilidad para una cita en una fecha y franja horaria especifica
     * 
     * @param date              La fecha en la que se desea agendar la cita.
     * @param timeSlot          El número que representa la franja horaria
     */
    public boolean isAvaible(LocalDate date, int timeSlot){
        return true;
    }
    
    /*
    * Obtiene la oficina del doctor
    */
    public Office getOffice(){
        return office;
    }
}
