import java.util.ArrayList;

public class PatientIllness {
	private int riskLevel;
	private Illness illness;
	private ArrayList<Treatment> treatments;
	private Appointment appointment;
}
